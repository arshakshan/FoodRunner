package com.arshak.foodrunner.model

data class FoodItem (
    val itemId: String,
    val itemName: String,
    val itemCost: Int,
    val restId: String


)
