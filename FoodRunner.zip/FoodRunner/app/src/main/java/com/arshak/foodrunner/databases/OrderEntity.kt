package com.arshak.foodrunner.databases

data class OrderEntity (
    val restaurantId: String

)