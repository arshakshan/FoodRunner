package com.arshak.foodrunner.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.widget.Toolbar
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.drawerlayout.widget.DrawerLayout
import com.arshak.foodrunner.R
import com.arshak.foodrunner.fragment.HomeFragment
import com.arshak.foodrunner.fragment.MenuFragment
import kotlinx.android.synthetic.main.activity_rest_menu.*

class RestMenuActivity : AppCompatActivity() {

    lateinit var drawerLayout: DrawerLayout
    lateinit var coordinatorLayout: CoordinatorLayout
    lateinit var toolbar: Toolbar
    lateinit var frameLayout: FrameLayout

    var resId: Int? = 0
    var resName: String? = ""


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rest_menu)

        toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        drawerLayout = findViewById(R.id.drawerLayout)
        coordinatorLayout = findViewById(R.id.coordinatorLayout)
        frameLayout = findViewById(R.id.frame)


        setUpToolbar()

        openMenu()

        /*if (intent != null) {
            resId = intent?.getIntExtra("id",0)
            resName = intent?.getStringExtra("name")

        } else {
            finish()
            Toast.makeText(
                this@RestMenuActivity,
                "Some unexpected error occurred! I ",
                Toast.LENGTH_SHORT
            ).show()
        }*/
    }

    fun openMenu() {
        val fragment = MenuFragment()
        val transaction = supportFragmentManager.beginTransaction()
        transaction.replace(R.id.frame, fragment)
        transaction.commit()

        supportActionBar?.title = "Menu"
    }

    fun setUpToolbar() {
        setSupportActionBar(toolbar)
        supportActionBar?.title = "Toolbar Title"
        supportActionBar?.setHomeButtonEnabled(true)

    }


}