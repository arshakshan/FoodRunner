package com.arshak.foodrunner.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.arshak.foodrunner.R
import com.arshak.foodrunner.model.Restaurant
import com.squareup.picasso.Picasso

class FavoritesRecyclerAdapter(val contextMenu: Context, val itemList: ArrayList<Restaurant>): RecyclerView.Adapter<FavoritesRecyclerAdapter.FavoritesViewHolder>() {
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): FavoritesRecyclerAdapter.FavoritesViewHolder {

        val view = LayoutInflater.from(parent.context).inflate(R.layout.recycler_fav_single_row, parent, false)

        return FavoritesViewHolder(view)

    }

    override fun getItemCount(): Int {

        return itemList.size

    }

    override fun onBindViewHolder(
        holder: FavoritesRecyclerAdapter.FavoritesViewHolder,
        position: Int
    ) {

        val restaurant = itemList[position]
        holder.txtRestaurantName.text = restaurant.restaurantName
        holder.txtCost.text = restaurant.restaurantCost.toString()
        holder.txtRatings.text = restaurant.restaurantRatings

        Picasso.get().load(restaurant.restaurantImage).error(R.drawable.default_restaurant).into(holder.imgRestaurant);



    }

    class FavoritesViewHolder(view: View): RecyclerView.ViewHolder(view){

        val txtRestaurantName: TextView = view.findViewById(R.id.txtRestaurantName)
        val txtCost: TextView = view.findViewById(R.id.txtCost)
        val txtRatings: TextView = view.findViewById(R.id.txtRatings)
        val imgRestaurant: ImageView = view.findViewById(R.id.imgRestaurant)
        val imgRupee: ImageView = view.findViewById(R.id.imgRupee)
        val imgFavorite: ImageView = view.findViewById(R.id.imgFavorite)
        val llContent: LinearLayout = view.findViewById(R.id.llContent)
        val txtPerPerson: TextView = view.findViewById(R.id.txtPerPerson)

    }


}

