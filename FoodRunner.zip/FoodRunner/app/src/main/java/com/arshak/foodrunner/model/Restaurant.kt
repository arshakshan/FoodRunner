package com.arshak.foodrunner.model

data class Restaurant (
    val restaurantId: Int,
    val restaurantName: String,
    val restaurantRatings: String,
    val restaurantCost: Int,
    val restaurantImage: String


)
