package com.arshak.foodrunner.adapter

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.arshak.foodrunner.R
import com.arshak.foodrunner.activity.RestMenuActivity
import com.arshak.foodrunner.fragment.MenuFragment
import com.arshak.foodrunner.model.Restaurant
import com.squareup.picasso.Picasso


class HomeRecyclerAdapter(val contextMenu: Context, val itemList: ArrayList<Restaurant>): RecyclerView.Adapter<HomeRecyclerAdapter.HomeViewHolder>() {
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): HomeViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.recycler_home_single_row,parent,false)

        return HomeViewHolder(
            view
        )
    }

    override fun getItemCount(): Int {
        return itemList.size
    }

    override fun onBindViewHolder(holder: HomeViewHolder, position: Int) {
        val restaurant = itemList[position]
        holder.txtRestaurantName.text = restaurant.restaurantName
        holder.txtCost.text = restaurant.restaurantCost.toString()
        holder.txtRatings.text = restaurant.restaurantRatings

        Picasso.get().load(restaurant.restaurantImage).error(R.drawable.default_restaurant).into(holder.imgRestaurant);

        holder.imgFavorite.setOnClickListener{
            holder.imgFavorite.setImageResource(R.drawable.ic_favorites)
            holder.imgFavorite.setOnClickListener{
                holder.imgFavorite.setImageResource(R.drawable.ic_favo)
            }

        }


        holder.llContent.setOnClickListener{

            val intent = Intent(contextMenu , RestMenuActivity::class.java)
            /*intent.putExtra("id", restaurant.restaurantId)
            intent.putExtra("name", restaurant.restaurantName.toString())*/
            contextMenu.startActivity(intent)


            Toast.makeText(contextMenu,"Clicked on ${holder.txtRestaurantName.text}",Toast.LENGTH_SHORT).show()
        }
    }

    class HomeViewHolder(view: View) : RecyclerView.ViewHolder(view){

        val txtRestaurantName: TextView = view.findViewById(R.id.txtRestaurantName)
        val txtCost: TextView = view.findViewById(R.id.txtCost)
        val txtRatings: TextView = view.findViewById(R.id.txtRatings)
        val imgRestaurant: ImageView = view.findViewById(R.id.imgRestaurant)
        val imgRupee: ImageView = view.findViewById(R.id.imgRupee)
        val imgFavorite: ImageView = view.findViewById(R.id.imgFavorite)
        val llContent: LinearLayout = view.findViewById(R.id.llContent)
        val txtPerPerson: TextView = view.findViewById(R.id.txtPerPerson)


    }
}