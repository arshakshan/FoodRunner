package com.arshak.foodrunner.fragment

interface DrawerLocker {
        fun setDrawerEnabled(enabled: Boolean)
}