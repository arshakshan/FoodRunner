package com.arshak.foodrunner.fragment

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.Volley
import com.arshak.foodrunner.adapter.HomeRecyclerAdapter
import com.arshak.foodrunner.R
import com.arshak.foodrunner.model.Restaurant
import com.arshak.foodrunner.util.ConnectionManager
import org.json.JSONException


class HomeFragment : Fragment() {

    lateinit var recyclerView: RecyclerView

    lateinit var layoutManager: RecyclerView.LayoutManager

    lateinit var recyclerRestaurant: RecyclerView

    lateinit var progressLayout: RelativeLayout

    lateinit var progressBar: ProgressBar

    lateinit var recyclerAdapter: HomeRecyclerAdapter

    val menuList = arrayListOf<Restaurant>()


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment

        val view = inflater.inflate(R.layout.fragment_home, container, false)

        setHasOptionsMenu(true)

        recyclerRestaurant = view.findViewById(R.id.recyclerRestaurant)

        recyclerAdapter = HomeRecyclerAdapter(
            activity as Context,
            menuList
        )

        layoutManager = LinearLayoutManager(activity)

        recyclerRestaurant.adapter =  recyclerAdapter
        recyclerRestaurant.layoutManager = layoutManager

        /*recyclerRestaurant.addItemDecoration(
            DividerItemDecoration(
                recyclerRestaurant.context,
                (layoutManager as LinearLayoutManager).orientation
            )
        )*/

        progressBar = view.findViewById(R.id.progressBar)
        progressLayout = view.findViewById(R.id.progressLayout)

        progressLayout.visibility = View.VISIBLE




        val queue = Volley.newRequestQueue(activity as Context)

        val url = "http://13.235.250.119/v2/restaurants/fetch_result/"

        if(ConnectionManager().checkConnectivity(activity as Context)){

                val jsonObjectRequest = object : JsonObjectRequest(Request.Method.GET, url, null, Response.Listener {

                    try{

                        progressLayout.visibility = View.GONE

                        val data = it.getJSONObject("data")

                        val success = data.getBoolean("success")

                        if(success){

                            val resArray = data.getJSONArray("data")
                            for(i in 0 until resArray.length()){

                                val restaurantJsonObject = resArray.getJSONObject(i)
                                val restaurantObject = Restaurant(

                                    restaurantJsonObject.getString("id").toInt(),
                                    restaurantJsonObject.getString("name"),
                                    restaurantJsonObject.getString("rating"),
                                    restaurantJsonObject.getString("cost_for_one").toInt(),
                                    restaurantJsonObject.getString("image_url")

                                )

                                menuList.add(restaurantObject)

                                recyclerAdapter =
                                    HomeRecyclerAdapter(
                                        activity as Context,
                                        menuList
                                    )

                                recyclerRestaurant.adapter =  recyclerAdapter
                                recyclerRestaurant.layoutManager = layoutManager
                                

                            }

                        }else{

                            Toast.makeText(activity as Context,"Some Error Has Occurred (3)!!!",Toast.LENGTH_SHORT).show()

                        }


                    }catch (e: JSONException){
                        Toast.makeText(activity as Context,"Some Error has Occurred (4) !!!", Toast.LENGTH_SHORT).show()
                    }

                }, Response.ErrorListener {

                    if(activity != null) {
                        Toast.makeText(
                            activity as Context,
                            "Volley error Occurred (5)!!!",
                            Toast.LENGTH_SHORT
                        ).show()
                    }

            } ) {

                    override fun getHeaders(): MutableMap<String, String> {
                        val headers = HashMap<String, String>()
                        headers["Content-type"] = "application/json"
                        headers["token"] = "40d294a3a614fa"
                        return headers
                    }
                }

            queue.add(jsonObjectRequest)
        }  else{

                    //Internet is not available

                    val dialog = AlertDialog.Builder(activity as Context)
                    dialog.setTitle("Error")
                    dialog.setMessage("Internet Connection Not Found")
                    dialog.setPositiveButton("Open Settings") { text, listener ->
                        val settingsIntent = Intent(Settings.ACTION_WIRELESS_SETTINGS)
                        startActivity(settingsIntent)
                        activity?.finish()
                    }

                    dialog.setNegativeButton("Exit"){text, listener->
                        ActivityCompat.finishAffinity(activity as Activity)
                    }

                    dialog.create()
                    dialog.show()

                }




return view
    }


}